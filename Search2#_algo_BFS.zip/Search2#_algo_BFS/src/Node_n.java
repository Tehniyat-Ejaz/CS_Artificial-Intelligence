/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tehniyat Ejaz
 */
public final class Node_n {
String val;
int state;
int action;
int cost;
Node_n Parent;
public Node_n()
{
                val=null;
		state = -1;
		cost = 0;
		action = -1;  //nothing
		Parent = null;
	}

public Node_n(String val,int st,int co,int act,Node_n parent)
{
        setVal(val);
	setState(st);
	setCost(co);
	setAction(act);
	setParent(parent);
}
void setVal(String Val)
{
    if(Val!=null)
        val=Val;
}
String getVal()
{
    return val;
}
void setState(int s)
{
 if (s >= 0)
   state = s;

}
int getState()
{
 return state;
}
void setCost(int c)
{
  if (c >= 0)
 {
   cost = c;
 }

}
int getCost()
{
  return cost;
}
void setAction(int a)
{
   if (a >= 0)
   {
     action = a;
   }
}
int getAction()
{
 return action;
}
void setParent(Node_n parent)
{
   if (parent != null)
   {
     Parent = parent;
   }
}
Node_n getParent()
{
return Parent;
}

  
boolean Goal_Test(Node_n goal)
{
    return (state == goal.state);
}
void disply()
{
    System.out.println("State of node is "+state+"\n");
    System.out.println("Action of node is "+action+"\n");
    System.out.println("Cost of node is "+cost+"\n");
    System.out.println("Parent of node is "+Parent.state+"\n");
  
}


}
