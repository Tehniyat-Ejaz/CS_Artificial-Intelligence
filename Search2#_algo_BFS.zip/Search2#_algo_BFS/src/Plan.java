import java.util.*; 
import java.util.LinkedList;
import java.util.Queue;
import javafx.scene.Node;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tehniyat Ejaz
 */
public class Plan {
      Node_n Initial;
    Node_n  Goal;
    
    public Plan()
    {
        Initial=null;
        Goal=null;
    }
    public Plan(Node_n I, Node_n G)
    {
        if (I != null)
        {
           Initial = I;
        }
        if (G != null)
        {
           Goal = G;
        }

    }
    void setInitial(Node_n n)  
    {
       if(n!=null)
       {
           Initial=n;
       }
        
    }
    Node_n getInitial()
    {
        return Initial;
    }
    void setGoal(Node_n n)  
    {
       if(n!=null)
       {
           Goal=n;
       }
        
    }
    Node_n getGoal()
    {
        return Goal;
    }
    boolean Goal_Test(int Given_State)
    {
      //  System.out.println("Goal_Test");
        return (Goal.state==Given_State);
    }
    void display() {
        System.out.println("Initial State : " +Initial.state+"\n" );
        System.out.println("Goal State : "+Goal.state+"\n");
    }
    int Actions(int node_state)
    {
       // System.out.println("Action Method");
        return 0;
    }
    
    int Result(int parent_state,int act,int[][] transition_model)
    {
      //   System.out.println("Result Method");
        return transition_model[parent_state][act];
    }
    int STEP_Cost(int parent_state,int act,int[][] transition_model)
    {
     int child_state=Result(parent_state,act,transition_model);
      Node_n n=new Node_n();
     n.state=child_state;
     n.Parent.state=parent_state;
      
     return n.cost;
    }
    Node_n Child_Node(Node_n Initial, Node_n Goal, Node_n node_parent, int action,int[][] transition_model)
    {
      // System.out.println("Child_node Method");
       Node_n node=new Node_n();
       node.state=Result(node_parent.state, action,transition_model);
       node.Parent=node_parent;
       node.action=action;
       node.cost=node_parent.cost+STEP_Cost(node_parent.state,action,transition_model);
        System.out.println(node);
       return node;
    }
    
    Queue<Node_n> Insert(Node_n child, Queue<Node_n> frontier) 
    {
    //  System.out.println("Insert Method");
     frontier.add(child);
     return frontier;
    }
     
    void Solution(Node_n node)
    {
    //    System.out.println("Solution Method");
        Stack<Node_n> s=new Stack();
        if(node==null)
        {
            System.out.println("No Solution Exist");
        }else{
            System.out.println("Solution is ");
            while(node!=null)
            {
                s.push(node);
      //          System.out.println("here node push");
                node=node.Parent;
            }

        while(!s.isEmpty())
        {
           Node_n pop_node = s.pop();
        //   System.out.println("here node pop");
            System.out.println(pop_node.state+" -> ");
        }
        
        
        }
        
            
    
    }
     public void SearchAlgo(int[][] transition_model,int Number_of_action)
    {
        //System.out.println("SearchAlgo Start");
          Node_n node=new Node_n();
          node=Initial;
          node.val=Initial.val;
          node.cost=0;
          node.state=Initial.state;
          if(Goal_Test(node.state))
          {
              Solution(node);
          }else
          {
          Queue<Node_n> frontier = new LinkedList<>();
          frontier.add(node);
          Set<Integer> explored_set = new HashSet<>(); 
          
          do{
              if(frontier.isEmpty())
              {
                  System.out.println("Frontier is empty..No solution");
              }else{
              node=frontier.poll();
              explored_set.add(node.state);
              
             
               for(int action=0;action<Number_of_action;action++){
                Node_n child=Child_Node(Initial,Goal,node,action,transition_model);
                 if(explored_set.contains(child.state)||frontier.contains(child))
                 {
                     if(Goal_Test(child.state))
                     {
                         Solution(child);
                     }
                     frontier=Insert(child,frontier);
                 }
                     System.out.println();
             }
              
              }
              
          }while(!frontier.isEmpty());

          }
          
          
          
          
  //   System.out.println("SearchAlgo End");

    }


    
  
     
     
}
     

     
     