
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.jmx.MXNodeAlgorithm;
import com.sun.javafx.jmx.MXNodeAlgorithmContext;
import com.sun.javafx.sg.prism.NGNode;
import java.util.Scanner;
import javafx.scene.Node;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tehniyat Ejaz
 */
public class driver {
    
    public static void main(String[] args) {
        
      
        System.out.println("__Breath First Search__");
           int m=0;   //m
           int n=0;   //n
           int t=0;   //t
          Scanner sc = new Scanner(System.in);
         
         System.out.println("***Welcome to Searching Plain Problem***\n");
        
         //give no of states, no of actions and no of plans
         System.out.println("Give total number of States,Number of actions \n"
                + " and Number of plans you want to get (give input in tab separated form)");
         String str = sc.nextLine();
         String[] strSplit = str .split(" ");
     
        m = Integer.parseInt(strSplit[0]);
        n = Integer.parseInt(strSplit[1]);
        t = Integer.parseInt(strSplit[2]);
  
         System.out.println(" ");
        
        //give no of states 
         String[] states=new String[m];
        System.out.println("__Enter Description of States__");
        for(int i=0;i<m;i++)
        {
            System.out.print("State "+i+" : ");
            states[i]=sc.next();
        }
        
         System.out.println(" ");
        
         //give no of actions
         String[] actions=new String[n];
        System.out.println("__Enter Description of Actions__");
        for(int i=0;i<n;i++)
        {
            System.out.print("Action "+i+" : ");
            actions[i]=sc.next();
        }
        System.out.println(" ");
        
        //give transition model
        int[][] transition_model=new int[m][n];
        System.out.println("__Enter Transition Model__");
        for(int i=0;i<m;i++)
        {
            System.out.println("Enter "+n+" Child of state "+i+" : ");
            for(int j=0;j<n;j++)
            {
                transition_model[i][j]=sc.nextInt();
            }
            System.out.println(" ");
        }
      
         //give no of plans
        String[][] plans=new String[t][2];
        System.out.println("__Enter Plans__");
        for(int i=0;i<t;i++)
        {
            System.out.println("Enter Plan "+i+" : " );
            for(int j=0;j<2;j++)
            {
                plans[i][j]=sc.next();
            } 
        }
        
        Node_n initial_node=new Node_n();
        Node_n goal_node=new Node_n();
        
         for(int i=0;i<t;i++)
        {
            System.out.println("Solution of Plan "+i+" : " );
            initial_node.val= plans[i][0];
            goal_node.val=plans[i][1];
            
      }
       
        
        
        
        Plan p=new Plan();
        
        p.Initial=initial_node;
        p.Goal=goal_node;
        p.Initial.val=initial_node.val;
        p.Goal.val=goal_node.val;
    //    p.Initial.action=node.action;
        p .Initial.val=plans[0][1];
        p.SearchAlgo(transition_model,n);
      
    
      
         
         
         
         
    }
   
}